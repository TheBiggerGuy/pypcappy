#!/usr/bin/env python3

from .pcapNgFile import PcapNgFile